// This file is @generated
package com.hooksniff.kotlin.models

import kotlinx.serialization.Serializable

@Serializable data class AdobeSignConfig(val clientId: String)
