// this file is @generated
package com.hooksniff.kotlin

import com.hooksniff.kotlin.models.BulkReplayIn
import com.hooksniff.kotlin.models.EndpointHeadersIn
import com.hooksniff.kotlin.models.EndpointHeadersOut
import com.hooksniff.kotlin.models.EndpointHeadersPatchIn
import com.hooksniff.kotlin.models.EndpointIn
import com.hooksniff.kotlin.models.EndpointOut
import com.hooksniff.kotlin.models.EndpointPatch
import com.hooksniff.kotlin.models.EndpointSecretOut
import com.hooksniff.kotlin.models.EndpointSecretRotateIn
import com.hooksniff.kotlin.models.EndpointStats
import com.hooksniff.kotlin.models.EndpointTransformationIn
import com.hooksniff.kotlin.models.EndpointTransformationOut
import com.hooksniff.kotlin.models.EndpointTransformationPatch
import com.hooksniff.kotlin.models.EndpointUpdate
import com.hooksniff.kotlin.models.EventExampleIn
import com.hooksniff.kotlin.models.ListResponseEndpointOut
import com.hooksniff.kotlin.models.MessageOut
import com.hooksniff.kotlin.models.Ordering
import com.hooksniff.kotlin.models.RecoverIn
import com.hooksniff.kotlin.models.RecoverOut
import com.hooksniff.kotlin.models.ReplayIn
import com.hooksniff.kotlin.models.ReplayOut
import kotlinx.datetime.Instant
import okhttp3.Headers

data class EndpointListOptions(
    /** Limit the number of returned items */
    val limit: ULong? = null,
    /** The iterator returned from a prior invocation */
    val iterator: String? = null,
    /** The sorting order of the returned items */
    val order: Ordering? = null,
)

data class EndpointCreateOptions(val idempotencyKey: String? = null)

data class EndpointBulkReplayOptions(val idempotencyKey: String? = null)

data class EndpointRecoverOptions(val idempotencyKey: String? = null)

data class EndpointReplayMissingOptions(val idempotencyKey: String? = null)

data class EndpointRotateSecretOptions(val idempotencyKey: String? = null)

data class EndpointSendExampleOptions(val idempotencyKey: String? = null)

data class EndpointGetStatsOptions(
    /** Filter the range to data starting from this date. */
    val since: Instant? = null,
    /** Filter the range to data ending by this date. */
    val until: Instant? = null,
)

class Endpoint(private val client: HookSniffHttpClient) {
    /** List the application's endpoints. */
    suspend fun list(
        appId: String,
        options: EndpointListOptions = EndpointListOptions(),
    ): ListResponseEndpointOut {
        val url = client.newUrlBuilder().encodedPath("/v1/endpoints")
        options.limit?.let { url.addQueryParameter("limit", serializeQueryParam(it)) }
        options.iterator?.let { url.addQueryParameter("iterator", it) }
        options.order?.let { url.addQueryParameter("order", serializeQueryParam(it)) }
        return client.executeRequest<Any, ListResponseEndpointOut>("GET", url.build())
    }

    /**
     * Create a new endpoint for the application.
     *
     * When `secret` is `null` the secret is automatically generated (recommended).
     */
    suspend fun create(
        appId: String,
        endpointIn: EndpointIn,
        options: EndpointCreateOptions = EndpointCreateOptions(),
    ): EndpointOut {
        val url = client.newUrlBuilder().encodedPath("/v1/endpoints")
        val headers = Headers.Builder()
        options.idempotencyKey?.let { headers.add("idempotency-key", it) }

        return client.executeRequest<EndpointIn, EndpointOut>(
            "POST",
            url.build(),
            headers = headers.build(),
            reqBody = endpointIn,
        )
    }

    /** Get an endpoint. */
    suspend fun get(appId: String, endpointId: String): EndpointOut {
        val url = client.newUrlBuilder().encodedPath("/v1/endpoints/$endpointId")
        return client.executeRequest<Any, EndpointOut>("GET", url.build())
    }

    /** Update an endpoint. */
    suspend fun update(
        appId: String,
        endpointId: String,
        endpointUpdate: EndpointUpdate,
    ): EndpointOut {
        val url = client.newUrlBuilder().encodedPath("/v1/endpoints/$endpointId")

        return client.executeRequest<EndpointUpdate, EndpointOut>(
            "PUT",
            url.build(),
            reqBody = endpointUpdate,
        )
    }

    /** Delete an endpoint. */
    suspend fun delete(appId: String, endpointId: String) {
        val url = client.newUrlBuilder().encodedPath("/v1/endpoints/$endpointId")
        client.executeRequest<Any, Boolean>("DELETE", url.build())
    }

    /** Partially update an endpoint. */
    suspend fun patch(
        appId: String,
        endpointId: String,
        endpointPatch: EndpointPatch,
    ): EndpointOut {
        val url = client.newUrlBuilder().encodedPath("/v1/endpoints/$endpointId")

        return client.executeRequest<EndpointPatch, EndpointOut>(
            "PATCH",
            url.build(),
            reqBody = endpointPatch,
        )
    }

    /**
     * Bulk replay messages sent to the endpoint.
     *
     * Only messages that were created after `since` will be sent. This will replay both successful,
     * and failed messages
     *
     * A completed task will return a payload like the following:
     * ```json
     * {
     *   "id": "qtask_33qen93MNuelBAq1T9G7eHLJRsF",
     *   "status": "finished",
     *   "task": "endpoint.bulk-replay",
     *   "data": {
     *     "messagesSent": 2
     *   }
     * }
     * ```
     */
    suspend fun bulkReplay(
        appId: String,
        endpointId: String,
        bulkReplayIn: BulkReplayIn,
        options: EndpointBulkReplayOptions = EndpointBulkReplayOptions(),
    ): ReplayOut {
        val url =
            client
                .newUrlBuilder()
                .encodedPath("/v1/endpoints/$endpointId/bulk-replay")
        val headers = Headers.Builder()
        options.idempotencyKey?.let { headers.add("idempotency-key", it) }

        return client.executeRequest<BulkReplayIn, ReplayOut>(
            "POST",
            url.build(),
            headers = headers.build(),
            reqBody = bulkReplayIn,
        )
    }

    /** Get the additional headers to be sent with the webhook. */
    suspend fun getHeaders(appId: String, endpointId: String): EndpointHeadersOut {
        val url =
            client.newUrlBuilder().encodedPath("/v1/endpoints/$endpointId/headers")
        return client.executeRequest<Any, EndpointHeadersOut>("GET", url.build())
    }

    /** Set the additional headers to be sent with the webhook. */
    suspend fun updateHeaders(
        appId: String,
        endpointId: String,
        endpointHeadersIn: EndpointHeadersIn,
    ) {
        val url =
            client.newUrlBuilder().encodedPath("/v1/endpoints/$endpointId/headers")

        client.executeRequest<EndpointHeadersIn, Boolean>(
            "PUT",
            url.build(),
            reqBody = endpointHeadersIn,
        )
    }

    /** Partially set the additional headers to be sent with the webhook. */
    suspend fun patchHeaders(
        appId: String,
        endpointId: String,
        endpointHeadersPatchIn: EndpointHeadersPatchIn,
    ) {
        val url =
            client.newUrlBuilder().encodedPath("/v1/endpoints/$endpointId/headers")

        client.executeRequest<EndpointHeadersPatchIn, Boolean>(
            "PATCH",
            url.build(),
            reqBody = endpointHeadersPatchIn,
        )
    }

    /**
     * Resend all failed messages since a given time.
     *
     * Messages that were sent successfully, even if failed initially, are not resent.
     *
     * A completed task will return a payload like the following:
     * ```json
     * {
     *   "id": "qtask_33qen93MNuelBAq1T9G7eHLJRsF",
     *   "status": "finished",
     *   "task": "endpoint.recover",
     *   "data": {
     *     "messagesSent": 2
     *   }
     * }
     * ```
     */
    suspend fun recover(
        appId: String,
        endpointId: String,
        recoverIn: RecoverIn,
        options: EndpointRecoverOptions = EndpointRecoverOptions(),
    ): RecoverOut {
        val url =
            client.newUrlBuilder().encodedPath("/v1/endpoints/$endpointId/recover")
        val headers = Headers.Builder()
        options.idempotencyKey?.let { headers.add("idempotency-key", it) }

        return client.executeRequest<RecoverIn, RecoverOut>(
            "POST",
            url.build(),
            headers = headers.build(),
            reqBody = recoverIn,
        )
    }

    /**
     * Replays messages to the endpoint.
     *
     * Only messages that were created after `since` will be sent. Messages that were previously
     * sent to the endpoint are not resent.
     *
     * A completed task will return a payload like the following:
     * ```json
     * {
     *   "id": "qtask_33qen93MNuelBAq1T9G7eHLJRsF",
     *   "status": "finished",
     *   "task": "endpoint.replay",
     *   "data": {
     *     "messagesSent": 2
     *   }
     * }
     * ```
     */
    suspend fun replayMissing(
        appId: String,
        endpointId: String,
        replayIn: ReplayIn,
        options: EndpointReplayMissingOptions = EndpointReplayMissingOptions(),
    ): ReplayOut {
        val url =
            client
                .newUrlBuilder()
                .encodedPath("/v1/endpoints/$endpointId/replay-missing")
        val headers = Headers.Builder()
        options.idempotencyKey?.let { headers.add("idempotency-key", it) }

        return client.executeRequest<ReplayIn, ReplayOut>(
            "POST",
            url.build(),
            headers = headers.build(),
            reqBody = replayIn,
        )
    }

    /**
     * Get the endpoint's signing secret.
     *
     * This is used to verify the authenticity of the webhook. For more information please refer to
     * [the consuming webhooks docs](https://hooksniff.vercel.app/docs).
     */
    suspend fun getSecret(appId: String, endpointId: String): EndpointSecretOut {
        val url =
            client.newUrlBuilder().encodedPath("/v1/endpoints/$endpointId/secret")
        return client.executeRequest<Any, EndpointSecretOut>("GET", url.build())
    }

    /**
     * Rotates the endpoint's signing secret.
     *
     * The previous secret will remain valid for the next 24 hours.
     */
    suspend fun rotateSecret(
        appId: String,
        endpointId: String,
        endpointSecretRotateIn: EndpointSecretRotateIn,
        options: EndpointRotateSecretOptions = EndpointRotateSecretOptions(),
    ) {
        val url =
            client
                .newUrlBuilder()
                .encodedPath("/v1/endpoints/$endpointId/secret/rotate")
        val headers = Headers.Builder()
        options.idempotencyKey?.let { headers.add("idempotency-key", it) }

        client.executeRequest<EndpointSecretRotateIn, Boolean>(
            "POST",
            url.build(),
            headers = headers.build(),
            reqBody = endpointSecretRotateIn,
        )
    }

    /** Send an example message for an event. */
    suspend fun sendExample(
        appId: String,
        endpointId: String,
        eventExampleIn: EventExampleIn,
        options: EndpointSendExampleOptions = EndpointSendExampleOptions(),
    ): MessageOut {
        val url =
            client
                .newUrlBuilder()
                .encodedPath("/v1/endpoints/$endpointId/send-example")
        val headers = Headers.Builder()
        options.idempotencyKey?.let { headers.add("idempotency-key", it) }

        return client.executeRequest<EventExampleIn, MessageOut>(
            "POST",
            url.build(),
            headers = headers.build(),
            reqBody = eventExampleIn,
        )
    }

    /** Get basic statistics for the endpoint. */
    suspend fun getStats(
        appId: String,
        endpointId: String,
        options: EndpointGetStatsOptions = EndpointGetStatsOptions(),
    ): EndpointStats {
        val url =
            client.newUrlBuilder().encodedPath("/v1/endpoints/$endpointId/stats")
        options.since?.let { url.addQueryParameter("since", serializeQueryParam(it)) }
        options.until?.let { url.addQueryParameter("until", serializeQueryParam(it)) }
        return client.executeRequest<Any, EndpointStats>("GET", url.build())
    }

    /** Get the transformation code associated with this endpoint. */
    suspend fun transformationGet(appId: String, endpointId: String): EndpointTransformationOut {
        val url =
            client
                .newUrlBuilder()
                .encodedPath("/v1/endpoints/$endpointId/transformation")
        return client.executeRequest<Any, EndpointTransformationOut>("GET", url.build())
    }

    /** Set or unset the transformation code associated with this endpoint. */
    suspend fun patchTransformation(
        appId: String,
        endpointId: String,
        endpointTransformationPatch: EndpointTransformationPatch,
    ) {
        val url =
            client
                .newUrlBuilder()
                .encodedPath("/v1/endpoints/$endpointId/transformation")

        client.executeRequest<EndpointTransformationPatch, Boolean>(
            "PATCH",
            url.build(),
            reqBody = endpointTransformationPatch,
        )
    }

    /**
     * This operation was renamed to `set-transformation`.
     *
     * @deprecated
     */
    @Deprecated("")
    suspend fun transformationPartialUpdate(
        appId: String,
        endpointId: String,
        endpointTransformationIn: EndpointTransformationIn,
    ) {
        val url =
            client
                .newUrlBuilder()
                .encodedPath("/v1/endpoints/$endpointId/transformation")

        client.executeRequest<EndpointTransformationIn, Boolean>(
            "PATCH",
            url.build(),
            reqBody = endpointTransformationIn,
        )
    }
}
