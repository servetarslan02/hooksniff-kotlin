// this file is @generated
package com.hooksniff.kotlin

import com.hooksniff.kotlin.models.ApiTokenOut
import com.hooksniff.kotlin.models.RotatePollerTokenIn
import com.hooksniff.kotlin.models.StreamPortalAccessIn
import com.hooksniff.kotlin.models.StreamTokenExpireIn
import com.hooksniff.kotlin.models.AppPortalAccessOut
import okhttp3.Headers

data class AuthenticationLogoutOptions(val idempotencyKey: String? = null)

data class AuthenticationStreamLogoutOptions(val idempotencyKey: String? = null)

data class AuthenticationStreamPortalAccessOptions(val idempotencyKey: String? = null)

data class AuthenticationStreamExpireAllOptions(val idempotencyKey: String? = null)

data class AuthenticationRotateStreamPollerTokenOptions(val idempotencyKey: String? = null)

class Authentication(private val client: HookSniffHttpClient) {

    /**
     * Logout an app token.
     *
     * Trying to log out other tokens will fail.
     */
    suspend fun logout(options: AuthenticationLogoutOptions = AuthenticationLogoutOptions()) {
        val url = client.newUrlBuilder().encodedPath("/v1/auth/logout")
        val headers = Headers.Builder()
        options.idempotencyKey?.let { headers.add("idempotency-key", it) }
        client.executeRequest<Any, Boolean>("POST", url.build(), headers = headers.build())
    }

    /**
     * Logout a stream token.
     *
     * Trying to log out other tokens will fail.
     */
    suspend fun streamLogout(
        options: AuthenticationStreamLogoutOptions = AuthenticationStreamLogoutOptions()
    ) {
        val url = client.newUrlBuilder().encodedPath("/v1/auth/stream-logout")
        val headers = Headers.Builder()
        options.idempotencyKey?.let { headers.add("idempotency-key", it) }
        client.executeRequest<Any, Boolean>("POST", url.build(), headers = headers.build())
    }

    /**
     * Use this function to get magic links (and authentication codes) for connecting your users to
     * the Stream Consumer Portal.
     */
    suspend fun streamPortalAccess(
        streamId: String,
        streamPortalAccessIn: StreamPortalAccessIn,
        options: AuthenticationStreamPortalAccessOptions = AuthenticationStreamPortalAccessOptions(),
    ): AppPortalAccessOut {
        val url = client.newUrlBuilder().encodedPath("/v1/auth/stream-portal-access/$streamId")
        val headers = Headers.Builder()
        options.idempotencyKey?.let { headers.add("idempotency-key", it) }

        return client.executeRequest<StreamPortalAccessIn, AppPortalAccessOut>(
            "POST",
            url.build(),
            headers = headers.build(),
            reqBody = streamPortalAccessIn,
        )
    }

    /** Expire all of the tokens associated with a specific stream. */
    suspend fun streamExpireAll(
        streamId: String,
        streamTokenExpireIn: StreamTokenExpireIn,
        options: AuthenticationStreamExpireAllOptions = AuthenticationStreamExpireAllOptions(),
    ) {
        val url = client.newUrlBuilder().encodedPath("/v1/auth/stream/$streamId/expire-all")
        val headers = Headers.Builder()
        options.idempotencyKey?.let { headers.add("idempotency-key", it) }

        client.executeRequest<StreamTokenExpireIn, Boolean>(
            "POST",
            url.build(),
            headers = headers.build(),
            reqBody = streamTokenExpireIn,
        )
    }

    /** Get the current auth token for the stream poller. */
    suspend fun getStreamPollerToken(streamId: String, sinkId: String): ApiTokenOut {
        val url =
            client
                .newUrlBuilder()
                .encodedPath("/v1/auth/stream/$streamId/sink/$sinkId/poller/token")
        return client.executeRequest<Any, ApiTokenOut>("GET", url.build())
    }

    /** Create a new auth token for the stream poller API. */
    suspend fun rotateStreamPollerToken(
        streamId: String,
        sinkId: String,
        rotatePollerTokenIn: RotatePollerTokenIn,
        options: AuthenticationRotateStreamPollerTokenOptions =
            AuthenticationRotateStreamPollerTokenOptions(),
    ): ApiTokenOut {
        val url =
            client
                .newUrlBuilder()
                .encodedPath("/v1/auth/stream/$streamId/sink/$sinkId/poller/token/rotate")
        val headers = Headers.Builder()
        options.idempotencyKey?.let { headers.add("idempotency-key", it) }

        return client.executeRequest<RotatePollerTokenIn, ApiTokenOut>(
            "POST",
            url.build(),
            headers = headers.build(),
            reqBody = rotatePollerTokenIn,
        )
    }
}
